/**
* @file <source.c>
* @brief <le programme reproduit le jeu sokoban>
* @author <Divi LE GALL>
* @version <Version 2>
*
* <Le programme reproduit le jeu sokoban.
* La grille de jeu est un tableau de caratères de taille 12x12.
* le but est de positionner les caisses sur les cibles.
* Vous déplacez le personnage qui correspond au @ avec les touches z, q, s, d respectivement
* au, bas, gauche et droite. Vous avez la possibilité d'annuler un mouvement avec la touche u.
* Vous pouvez aussi zoomer et dézoomer la grille avec les touches + et -.
* Vous pouvez enregistrer votre progression avec la touche e ou recommencer la partie avec r.
* Le jeu s'arrête quand vous avez positionné toutes les caisses sur les cibles ou abandonné la partie avec x.
* À la fin de votre partie vous pouvez enregistrer vos déplacements dans un fichier .dep.>
*
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

#define TAILLE 12

typedef char t_Plateau[TAILLE][TAILLE];
typedef char t_tabDeplacement[1000];

const int MAX_ZOOM = 3;

void lecture(t_Plateau plat, char fichier[]);
void charger_partie(t_Plateau plateau, char fichier[]);
void enregistrer_partie(t_Plateau plateau, char fichier[]);
void afficher_plateau(t_Plateau plateau);
void afficher_en_tete(char fichier[], int nbDeplacement);
void nb_cibles(t_Plateau plateau, int * compteur);
void deplace(t_Plateau plateau, t_Plateau plateauInitial,char touche, char fichier[], int lig, int col, int *nbDeplacement,char *dep, t_tabDeplacement tabDep);
void lire(char * touche);
bool gagne(t_Plateau plateau,int compteur);
void position(t_Plateau plateau, int * lig, int * col);
void deplace_h(t_Plateau plateau, int lig, int col);
void deplace_b(t_Plateau plateau, int lig, int col);
void deplace_g(t_Plateau plateau, int lig, int col);
void deplace_d(t_Plateau plateau, int lig, int col);
void deplace_H(t_Plateau plateau, int lig, int col);
void deplace_B(t_Plateau plateau, int lig, int col);
void deplace_G(t_Plateau plateau, int lig, int col);
void deplace_D(t_Plateau plateau, int lig, int col);
void recommencer_partie(t_Plateau plateau, t_Plateau plateauInitial);
void zoomGrille(char grille[TAILLE][TAILLE], int nbZoom);
void zoom(t_Plateau plateau, char touche, int *nbZoom);
void affiche(t_tabDeplacement tab, int tailleDeplacement);
void annuler_deplacement(t_Plateau tab, t_tabDeplacement tabDep, char touche, char *dep, int *nbDeplacement, int lig, int col);
void annule_h(t_Plateau tab, int lig, int col);
void annule_H(t_Plateau tab, int lig, int col);
void annule_b(t_Plateau tab, int lig, int col);
void annule_B(t_Plateau tab, int lig, int col);
void annule_g(t_Plateau tab, int lig, int col);
void annule_G(t_Plateau tab, int lig, int col);
void annule_d(t_Plateau tab, int lig, int col);
void annule_D(t_Plateau tab, int lig, int col);
void enregistrer_deplacements(t_tabDeplacement t, int nb, char fic[]);
void demande_sauvegarde(t_tabDeplacement t, int nb);





int main(){
    t_Plateau tab;
    t_Plateau tabIni;
    t_tabDeplacement tabDeplacement;
    char fichier[TAILLE];
    char touche = '\0';
    char deplacement;
    int compteur = 0;
    int lig =  0, col = 0;
    int nbZoom = 1;
    int nbDep = 0;
    //char fic_sauvegarde[50];
    lecture(tab, fichier);
    afficher_plateau(tab);
    nb_cibles(tab, &compteur);
    recommencer_partie(tabIni, tab);
    while(gagne(tab, compteur) == false && touche != 'x'){
    position(tab, &lig, &col);
    lire(&touche);
    zoom(tab, touche, &nbZoom);
    if (touche == 'u'){
        annuler_deplacement(tab, tabDeplacement, touche, &deplacement, &nbDep, lig, col);
    }
    else {
        deplace(tab, tabIni, touche, fichier, lig, col, &nbDep, &deplacement, tabDeplacement);
    }
    gagne(tab, compteur);
    afficher_en_tete(fichier, nbDep);
    if(nbZoom == 1){
        afficher_plateau(tab);
        affiche(tabDeplacement, nbDep);
    } else {
        zoomGrille(tab, nbZoom);
    }
}

    if(gagne(tab,compteur) == true){
        printf("Vous avez gagné !");
        //enregistrer_deplacements(tabDeplacement, nbDep, fic_sauvegarde);
    }
    else {
        printf("Vous avez abandonné");
        //enregistrer_deplacements(tabDeplacement, nbDep, fic_sauvegarde);
    }
    return EXIT_SUCCESS;
}


void lecture(t_Plateau plat, char fichier[]){
    printf("Quel niveau voulez vous ?\n");
    scanf("%s", fichier);
    charger_partie(plat, fichier);
}

void afficher_plateau(t_Plateau plateau){
    for(int i = 0; i< TAILLE; i++){
        for(int j = 0; j < TAILLE; j++){
            if(plateau[i][j] == '+'){
                printf("%c", '@'); 
            }
            else if(plateau[i][j] == '*'){
                printf("%c", '$'); 
            }
            else {
                printf("%c", plateau[i][j]);  
            }
        }
        printf("\n");
    }
}


void afficher_en_tete(char fichier[], int nbDeplacement){
    system("clear");
    printf("%s", fichier);
    printf("\n");
    printf("touches de déplacement : z (haut),s (bas),q (gauche),d (droite) \n");
    printf("Pour arrêter la partie : x\n");
    printf("Pour recommencer la partie : r\n");
    printf("Pour enregistrer votre progression : e\n");
    printf("Nombres de déplacement : %d\n", nbDeplacement);

    
}

int kbhit(){
	// la fonction retourne :
	// 1 si un caractere est present
	// 0 si pas de caractere présent
	int unCaractere=0;
	struct termios oldt, newt;
	int ch;
	int oldf;

	// mettre le terminal en mode non bloquant
	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
 
	ch = getchar();

	// restaurer le mode du terminal
	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	fcntl(STDIN_FILENO, F_SETFL, oldf);
 
	if(ch != EOF){
		ungetc(ch, stdin);
		unCaractere=1;
	} 
	return unCaractere;
}

void lire(char * touche){
    while(kbhit() == 0){
    }
    * touche = getchar();
}


bool gagne(t_Plateau plateau,int compteur){
    int nbetoile = 0; 
    for(int i = 0; i < TAILLE; i++){
        for(int j = 0; j < TAILLE; j++){
            if(plateau[i][j] == '*'){
                nbetoile += 1;
            }
        }
    }
    if(nbetoile == compteur){
        return true;
    }
    else {
        return false;
    }
}


void charger_partie(t_Plateau plateau, char fichier[]){
    FILE * f;
    char finDeLigne;

    f = fopen(fichier, "r");
    if (f==NULL){
        printf("ERREUR SUR FICHIER");
        exit(EXIT_FAILURE);
    } else {
        for (int ligne=0 ; ligne<TAILLE ; ligne++){
            for (int colonne=0 ; colonne<TAILLE ; colonne++){
                fread(&plateau[ligne][colonne], sizeof(char), 1, f);
            }
            fread(&finDeLigne, sizeof(char), 1, f);
        }
        fclose(f);
    }
}
    

void enregistrer_partie(t_Plateau plateau, char fichier[]){
    FILE * f;
    char finDeLigne='\n';

    f = fopen(fichier, "w");
    for (int ligne=0 ; ligne<TAILLE ; ligne++){
        for (int colonne=0 ; colonne<TAILLE ; colonne++){
            fwrite(&plateau[ligne][colonne], sizeof(char), 1, f);
        }
        fwrite(&finDeLigne, sizeof(char), 1, f);
    }
    fclose(f);
}


void nb_cibles(t_Plateau plateau, int * compteur){
    for(int i = 0; i < TAILLE; i++){
        for(int j = 0; j < TAILLE; j++){
            if(plateau[i][j] == '.'){
                * compteur +=1;
            }
        }
    }
}


void position(t_Plateau plateau, int * lig, int * col){
    for (int i = 0; i < TAILLE; i++){
        for(int j = 0; j < TAILLE; j++){
            if(plateau[i][j] == '@'|| plateau[i][j] == '+'){
                * lig = i;
                * col = j;
            }
        }
    }
}

void deplace(t_Plateau plateau, t_Plateau plateauInitial,char touche, char fichier[], int lig, int col, int *nbDeplacement,char *dep, t_tabDeplacement tabDep){
    if(touche == 'r'){
        recommencer_partie(plateau, plateauInitial);
        *nbDeplacement = 0;
        tabDep[0] = '\0';
    }
    else if(touche == 'z'){
        if (plateau[lig-1][col] == ' ' || plateau[lig-1][col] == '.'){
            deplace_h(plateau, lig, col);
            *dep = 'h';
            if(plateau[lig-1][col] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
        else if(plateau[lig-2][col] != '#' && plateau[lig-2][col] != '$' && plateau[lig-2][col] != '*'){
            deplace_H(plateau, lig, col);
            *dep = 'H';
            if(plateau[lig-1][col] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
    }
    else if(touche == 's'){
        if (plateau[lig+1][col] == ' ' || plateau[lig+1][col] == '.'){
            deplace_b(plateau, lig, col);
            *dep = 'b';
            if(plateau[lig+1][col] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
        else if(plateau[lig+2][col] != '#' && plateau[lig+2][col] != '$' && plateau[lig+2][col] != '*'){
            deplace_B(plateau, lig, col);
            *dep ='B';
            if(plateau[lig+1][col] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
    }
    else if(touche == 'q'){
        if (plateau[lig][col-1] == ' ' || plateau[lig][col-1] == '.'){
            deplace_g(plateau, lig, col);
            *dep ='g';
            if(plateau[lig][col-1] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
        else if(plateau[lig][col-2] != '#' && plateau[lig][col-2] != '$' && plateau[lig][col-2] != '*'){
            deplace_G(plateau, lig, col);
            *dep = 'G';
            if(plateau[lig][col-1] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
    }
    else if(touche == 'd' && plateau[lig][col+1] != '#'){
        if (plateau[lig][col+1] == ' ' || plateau[lig][col+1] == '.'){
            deplace_d(plateau, lig, col);
            *dep = 'd';
            if(plateau[lig][col+1] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
        else if(plateau[lig][col+2] != '#' && plateau[lig][col+2] != '$' && plateau[lig][col+2] != '*'){
            deplace_D(plateau, lig, col);
            *dep = 'D';
            if(plateau[lig][col+1] != '#'){
                tabDep[*nbDeplacement] = *dep;
                (*nbDeplacement)++;
            }
        }
    }
    else if(touche == 'e'){
        enregistrer_partie(plateau, fichier);
    }
}


void deplace_h(t_Plateau plateau, int lig, int col) {
    if(plateau[lig][col] == '+'){
        plateau[lig][col] = '.';
    }
    else{
        plateau[lig][col] = ' ';
    }
    if(plateau[lig-1][col] == '.'){
        plateau[lig-1][col] = '+';
    }
    else {
        plateau[lig-1][col] = '@';
        }
}


void deplace_H(t_Plateau plateau, int lig, int col){
    if (plateau[lig-1][col] == '$' || plateau[lig-1][col] == '*'){
        if (plateau[lig-2][col] == '.'){
            plateau[lig-2][col] = '*';
        }
        else {
            plateau[lig-2][col] = '$';
        }
        if (plateau[lig-1][col] == '*'){
            plateau[lig-1][col] = '+';
        }
        else {
            plateau[lig-1][col] = '@';
        }
        if(plateau[lig][col] == '+'){
            plateau[lig][col] = '.';
        }
        else {
            plateau[lig][col] = ' ';
        }
    }
}


void deplace_b(t_Plateau plateau, int lig, int col) {
    if(plateau[lig][col] == '+'){
        plateau[lig][col] = '.';
    }
    else{
        plateau[lig][col] = ' ';
    }
    if(plateau[lig+1][col] == '.'){
        plateau[lig+1][col] = '+';
    }
    else {
        plateau[lig+1][col] = '@';
    }
}


void deplace_B(t_Plateau plateau, int lig, int col){
    if (plateau[lig+1][col] == '$' || plateau[lig+1][col] == '*'){
        if (plateau[lig+2][col] == '.'){
            plateau[lig+2][col] = '*';
        }
        else {
            plateau[lig+2][col] = '$';
        }
        if (plateau[lig+1][col] == '*'){
            plateau[lig+1][col] = '+';
        }
        else {
            plateau[lig+1][col] = '@';
        }
        if(plateau[lig][col] == '+'){
                plateau[lig][col] = '.';
        }
        else {
            plateau[lig][col] = ' ';
        }
    }
}


void deplace_g(t_Plateau plateau, int lig, int col) {
    if(plateau[lig][col] == '+'){
        plateau[lig][col] = '.';
    }
    else{
        plateau[lig][col] = ' ';
    }
    if(plateau[lig][col-1] == '.'){
        plateau[lig][col-1] = '+';
    }
    else {
        plateau[lig][col-1] = '@';
    }
}


void deplace_G(t_Plateau plateau, int lig, int col){
    if (plateau[lig][col-1] == '$' || plateau[lig][col-1] == '*'){
        if (plateau[lig][col-2] == '.'){
            plateau[lig][col-2] = '*';
        }
        else {
            plateau[lig][col-2] = '$';
        }
        if (plateau[lig][col-1] == '*'){
            plateau[lig][col-1] = '+';
        }
        else {
            plateau[lig][col-1] = '@';
        }
        if(plateau[lig][col] == '+'){
            plateau[lig][col] = '.';
        }
        else {
            plateau[lig][col] = ' ';
        }
    } 
}


void deplace_d(t_Plateau plateau, int lig, int col) {
    if(plateau[lig][col] == '+'){
        plateau[lig][col] = '.';
    }
    else{
        plateau[lig][col] = ' ';
    }
    if(plateau[lig][col+1] == '.'){
        plateau[lig][col+1] = '+';
    }
    else {
        plateau[lig][col+1] = '@';
    }   
}


void deplace_D(t_Plateau plateau, int lig, int col){
    if (plateau[lig][col+1] == '$' || plateau[lig][col+1] == '*'){
        if (plateau[lig][col+2] == '.'){
            plateau[lig][col+2] = '*';
        }
        else {
            plateau[lig][col+2] = '$';
        }
        if (plateau[lig][col+1] == '*'){
            plateau[lig][col+1] = '+';
        }
        else {
            plateau[lig][col+1] = '@';
        }
        if(plateau[lig][col] == '+'){
            plateau[lig][col] = '.';
        }
        else {
            plateau[lig][col] = ' ';
        }
    }
}


void recommencer_partie(t_Plateau plateau, t_Plateau plateauInitial){
    for (int i = 0; i < TAILLE; i++) {
        for (int j = 0; j < TAILLE; j++) {
            plateau[i][j] = plateauInitial[i][j];
        }
    }
}

void enregistrer_deplacements(t_tabDeplacement t, int nb, char fic[]){
    FILE * f;
    f = fopen(fic, "w");
    fwrite(t,sizeof(char), nb, f);
    fclose(f);
}


void zoomGrille(t_Plateau plateau, int nbZoom) {
    for (int i = 0; i < TAILLE; i++) {
        for (int j= 0; j < nbZoom; j++) {
            for (int k = 0; k < TAILLE; k++) {
                for (int l = 0; l < nbZoom; l++) {
                    if(plateau[i][k] == '+'){
                        printf("%c", '@'); 

                    }
                    else if(plateau[i][k] == '*'){
                        printf("%c", '$'); 
                    }
                    else {
                        printf("%c", plateau[i][k]);  
                    }
                }
            }
            printf("\n");
        }
    }
}


void zoom(t_Plateau plateau, char touche, int * nbZoom){
    if(touche == '+'){
        
        if(*nbZoom < MAX_ZOOM){
            *nbZoom += 1;
        }
    }
    else if(touche == '-' && *nbZoom > 1){
        *nbZoom -= 1;
    }
}

void affiche(t_tabDeplacement tab, int tailleDeplacement){
    for(int i = 0; i < tailleDeplacement; i++){
            printf("%c", tab[i]);
    }
}

void annuler_deplacement(t_Plateau tab, t_tabDeplacement tabDep, char touche, char *dep, int *nbDeplacement, int lig, int col){
    if(touche == 'u' && *nbDeplacement >= 0){
        (*nbDeplacement)--;
        *dep = tabDep[*nbDeplacement];
        tabDep[*nbDeplacement] = '\0';
        if(*dep == 'h'){
            annule_h(tab, lig, col);
        }
        else if(*dep == 'H'){
            annule_H(tab, lig, col);
        }

        else if(*dep == 'b'){
            annule_b(tab, lig, col);
        }
        else if(*dep == 'B'){
            annule_B(tab, lig, col);
        }

        else if(*dep == 'g'){
            annule_g(tab, lig, col);
        }
        else if(*dep == 'G'){
            annule_G(tab, lig, col);
        }

        else if(*dep == 'd'){
            annule_d(tab, lig, col);
        }
        else if(*dep == 'D'){
            annule_D(tab, lig, col);
        }
    }
}

void annule_h(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    } 
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig+1][col] == ' '){
        tab[lig+1][col] = '@';
    }
    else if(tab[lig+1][col] == '.'){
         tab[lig+1][col] = '+';
    }
}

void annule_H(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    }
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig+1][col] == ' '){
        tab[lig+1][col] = '@';
    }
    else if(tab[lig+1][col] == '.'){
        tab[lig+1][col] = '+';
    }

    if(tab[lig-1][col] == '$'){
        tab[lig-1][col] = ' ';
    }
    else if(tab[lig-1][col] == '*'){
        tab[lig-1][col] = '.';
    }
    if(tab[lig][col] == ' '){
        tab[lig][col] = '$';
    }
    else if(tab[lig][col] == '.'){
        tab[lig][col] = '*';
    }
}

void annule_b(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    } 
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig-1][col] == ' '){
        tab[lig-1][col] = '@';
    }
    else if(tab[lig-1][col] == '.'){
         tab[lig-1][col] = '+';
    }
}

void annule_B(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    }
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig-1][col] == ' '){
        tab[lig-1][col] = '@';
    }
    else if(tab[lig-1][col] == '.'){
        tab[lig-1][col] = '+';
    }

    if(tab[lig+1][col] == '$'){
        tab[lig+1][col] = ' ';
    }
    else if(tab[lig+1][col] == '*'){
        tab[lig+1][col] = '.';
    }
    if(tab[lig][col] == ' '){
        tab[lig][col] = '$';
    }
    else if(tab[lig][col] == '.'){
        tab[lig][col] = '*';
    }
}

void annule_g(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    } 
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig][col+1] == ' '){
        tab[lig][col+1] = '@';
    }
    else if(tab[lig][col+1] == '.'){
         tab[lig][col+1] = '+';
    }
}

void annule_G(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    }
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig][col+1] == ' '){
        tab[lig][col+1] = '@';
    }
    else if(tab[lig][col+1] == '.'){
        tab[lig][col+1] = '+';
    }

    if(tab[lig][col-1] == '$'){
        tab[lig][col-1] = ' ';
    }
    else if(tab[lig][col-1] == '*'){
        tab[lig][col-1] = '.';
    }
    if(tab[lig][col] == ' '){
        tab[lig][col] = '$';
    }
    else if(tab[lig][col] == '.'){
        tab[lig][col] = '*';
    }
}

void annule_d(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    } 
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig][col-1] == ' '){
        tab[lig][col-1] = '@';
    }
    else if(tab[lig][col-1] == '.'){
         tab[lig][col-1] = '+';
    }
}

void annule_D(t_Plateau tab, int lig, int col){
    if(tab[lig][col] == '@'){
        tab[lig][col] = ' ';
    }
    else if(tab[lig][col] == '+'){
        tab[lig][col] = '.';
    }
    if(tab[lig][col-1] == ' '){
        tab[lig][col-1] = '@';
    }
    else if(tab[lig][col-1] == '.'){
        tab[lig][col-1] = '+';
    }

    if(tab[lig][col+1] == '$'){
        tab[lig][col+1] = ' ';
    }
    else if(tab[lig][col+1] == '*'){
        tab[lig][col+1] = '.';
    }
    if(tab[lig][col] == ' '){
        tab[lig][col] = '$';
    }
    else if(tab[lig][col] == '.'){
        tab[lig][col] = '*';
    }
}


void demande_sauvegarde(t_tabDeplacement t, int nb){
    char rep;
    char nomFichier[50];
    printf("Voulez-vous enregistrer vos déplacements ? (o/n) : ");
    scanf(" %c", &rep);
    if (rep == 'o'){
        printf("Nom du fichier (nomFichier.dep) : ");
        scanf("%s", nomFichier);
        enregistrerDeplacements(t, nb, nomFichier);
        printf("Déplacements enregistrés : %s\n", nomFichier);
    } else {
        printf("Déplacements non enregistrés.\n");
    }
}

