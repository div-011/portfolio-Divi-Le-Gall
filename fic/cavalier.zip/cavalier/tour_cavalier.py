# SAE - Le Tour du Cavalier
# Fevzi Emré GUNDUZ, Divi LE GALL - Groupe 1A2

# Les 8 mouvements possibles du cavalier
mouvements_x = [-2, -2, -1, -1,  1,  1,  2,  2]
mouvements_y = [-1,  1, -2,  2, -2,  2, -1,  1]

def est_valide(x, y, echiquier, taille):
    """Verifie si la case (x, y) est accessible"""
    return 0 <= x < taille and 0 <= y < taille and echiquier[x][y] == 0

def afficher_echiquier(echiquier, taille):
    """Affiche l'echiquier"""
    print("+" + "----+" * taille)
    for ligne in echiquier:
        print("|" + "".join(f" {v:2} |" for v in ligne))
        print("+" + "----+" * taille)

def nb_voisins(x, y, echiquier, taille):
    """Compte les cases accessibles depuis (x, y)"""
    compte = 0
    for i in range(8):
        nx = x + mouvements_x[i]
        ny = y + mouvements_y[i]
        if est_valide(nx, ny, echiquier, taille):
            compte += 1
    return compte

def trouver_voisins_tries(x, y, echiquier, taille):
    """Retourne les voisins tries par nombre de sorties (Warnsdorff)"""
    voisins = []
    for i in range(8):
        nx = x + mouvements_x[i]
        ny = y + mouvements_y[i]
        if est_valide(nx, ny, echiquier, taille):
            degre = nb_voisins(nx, ny, echiquier, taille)
            voisins.append((degre, nx, ny))
    # Tri a bulles pour trier par degre croissant (pour réduire les impasses), sans ça le programme mettait des heures sur les grands échiquiers"
    for i in range(len(voisins)):
        for j in range(i + 1, len(voisins)):
            if voisins[i][0] > voisins[j][0]:
                voisins[i], voisins[j] = voisins[j], voisins[i]
    return voisins

def cavalier(x, y, etape, echiquier, taille):
    """Chemin hamiltonien - retourne True si une solution est trouvee"""
    echiquier[x][y] = etape

    if etape == taille * taille:
        return True

    voisins = trouver_voisins_tries(x, y, echiquier, taille)
    for degre, nx, ny in voisins:
        if cavalier(nx, ny, etape + 1, echiquier, taille):
            return True

    echiquier[x][y] = 0  # backtrack
    return False

def cavalier_cycle(x, y, etape, echiquier, taille, depart_x, depart_y):
    """Tour ferme - verifie aussi qu'on peut revenir au depart"""
    echiquier[x][y] = etape

    if etape == taille * taille:
        for i in range(8):
            if x + mouvements_x[i] == depart_x and y + mouvements_y[i] == depart_y:
                return True
        echiquier[x][y] = 0
        return False

    voisins = trouver_voisins_tries(x, y, echiquier, taille)
    for degre, nx, ny in voisins:
        if cavalier_cycle(nx, ny, etape + 1, echiquier, taille, depart_x, depart_y):
            return True

    echiquier[x][y] = 0  # backtrack
    return False


# --- CAS 1 : Chemin hamiltonien 8x8 (Figure 3) ---
print("--- Chemin hamiltonien 8x8, depart (0, 7) ---")
echiquier = [[0] * 8 for _ in range(8)]
if cavalier(0, 7, 1, echiquier, 8):
    print("Solution trouvee !")
    afficher_echiquier(echiquier, 8)
else:
    print("Pas de solution")

# --- CAS 2 : Tour ferme 6x6 (Figure 4a) ---
print("\n--- Tour ferme 6x6, depart (5, 0) ---")
echiquier = [[0] * 6 for _ in range(6)]
if cavalier_cycle(5, 0, 1, echiquier, 6, 5, 0):
    print("Solution trouvee !")
    afficher_echiquier(echiquier, 6)
else:
    print("Pas de solution")

# --- CAS 3 : Tour ferme 8x8 (Figure 4b) ---
print("\n--- Tour ferme 8x8, depart (3, 2) ---")
echiquier = [[0] * 8 for _ in range(8)]
if cavalier_cycle(3, 2, 1, echiquier, 8, 3, 2):
    print("Solution trouvee !")
    afficher_echiquier(echiquier, 8)
else:
    print("Pas de solution")

# --- CAS 4 : Test 3x3 et 4x4 ---
print("\n--- Test 3x3 ---")
trouve = False
for i in range(3):
    for j in range(3):
        echiquier = [[0] * 3 for _ in range(3)]
        if cavalier(i, j, 1, echiquier, 3):
            trouve = True
            break
print("Solution trouvee !" if trouve else "Impossible")

print("\n--- Test 4x4 ---")
trouve = False
for i in range(4):
    for j in range(4):
        echiquier = [[0] * 4 for _ in range(4)]
        if cavalier(i, j, 1, echiquier, 4):
            trouve = True
            break
print("Solution trouvee !" if trouve else "Impossible")