<?php
$data_dept = array (
  0 => 
  array (
    'dept_code' => 95,
    'dept_nom' => 'Val-d\'Oise',
    'total_visiteurs' => 0,
  ),
  1 => 
  array (
    'dept_code' => 94,
    'dept_nom' => 'Val-de-Marne',
    'total_visiteurs' => 200,
  ),
  2 => 
  array (
    'dept_code' => 93,
    'dept_nom' => 'Seine-Saint-Denis',
    'total_visiteurs' => 150,
  ),
  3 => 
  array (
    'dept_code' => 92,
    'dept_nom' => 'Hauts-de-Seine',
    'total_visiteurs' => 1500,
  ),
  4 => 
  array (
    'dept_code' => 91,
    'dept_nom' => 'Essonne',
    'total_visiteurs' => 500,
  ),
  5 => 
  array (
    'dept_code' => 90,
    'dept_nom' => 'Territoire de Belfort',
    'total_visiteurs' => 200,
  ),
  6 => 
  array (
    'dept_code' => 89,
    'dept_nom' => 'Yonne',
    'total_visiteurs' => 80,
  ),
  7 => 
  array (
    'dept_code' => 88,
    'dept_nom' => 'Vosges',
    'total_visiteurs' => 350,
  ),
  8 => 
  array (
    'dept_code' => 87,
    'dept_nom' => 'Haute-Vienne',
    'total_visiteurs' => 300,
  ),
  9 => 
  array (
    'dept_code' => 86,
    'dept_nom' => 'Vienne',
    'total_visiteurs' => 1900,
  ),
  10 => 
  array (
    'dept_code' => 85,
    'dept_nom' => 'Vendee',
    'total_visiteurs' => 2300,
  ),
  11 => 
  array (
    'dept_code' => 84,
    'dept_nom' => 'Vaucluse',
    'total_visiteurs' => 650,
  ),
  12 => 
  array (
    'dept_code' => 83,
    'dept_nom' => 'Var',
    'total_visiteurs' => 4000,
  ),
  13 => 
  array (
    'dept_code' => 82,
    'dept_nom' => 'Tarn-et-Garonne',
    'total_visiteurs' => 180,
  ),
  14 => 
  array (
    'dept_code' => 81,
    'dept_nom' => 'Tarn',
    'total_visiteurs' => 500,
  ),
  15 => 
  array (
    'dept_code' => 80,
    'dept_nom' => 'Somme',
    'total_visiteurs' => 2000,
  ),
  16 => 
  array (
    'dept_code' => 79,
    'dept_nom' => 'Deux-Sevres',
    'total_visiteurs' => 900,
  ),
  17 => 
  array (
    'dept_code' => 78,
    'dept_nom' => 'Yvelines',
    'total_visiteurs' => 8100,
  ),
  18 => 
  array (
    'dept_code' => 77,
    'dept_nom' => 'Seine-et-Marne',
    'total_visiteurs' => 15000,
  ),
  19 => 
  array (
    'dept_code' => 76,
    'dept_nom' => 'Seine-Maritime',
    'total_visiteurs' => 0,
  ),
  20 => 
  array (
    'dept_code' => 75,
    'dept_nom' => 'Paris',
    'total_visiteurs' => 12000,
  ),
  21 => 
  array (
    'dept_code' => 74,
    'dept_nom' => 'Haute-Savoie',
    'total_visiteurs' => 3000,
  ),
  22 => 
  array (
    'dept_code' => 73,
    'dept_nom' => 'Savoie',
    'total_visiteurs' => 1200,
  ),
  23 => 
  array (
    'dept_code' => 72,
    'dept_nom' => 'Sarthe',
    'total_visiteurs' => 500,
  ),
  24 => 
  array (
    'dept_code' => 71,
    'dept_nom' => 'Saone-et-Loire',
    'total_visiteurs' => 200,
  ),
  25 => 
  array (
    'dept_code' => 70,
    'dept_nom' => 'Haute-Saone',
    'total_visiteurs' => 100,
  ),
  26 => 
  array (
    'dept_code' => 69,
    'dept_nom' => 'Rhone',
    'total_visiteurs' => 2500,
  ),
  27 => 
  array (
    'dept_code' => 68,
    'dept_nom' => 'Haut-Rhin',
    'total_visiteurs' => 250,
  ),
  28 => 
  array (
    'dept_code' => 67,
    'dept_nom' => 'Bas-Rhin',
    'total_visiteurs' => 4500,
  ),
  29 => 
  array (
    'dept_code' => 66,
    'dept_nom' => 'Pyrenees-Orientales',
    'total_visiteurs' => 200,
  ),
  30 => 
  array (
    'dept_code' => 65,
    'dept_nom' => 'Hautes-Pyrenees',
    'total_visiteurs' => 850,
  ),
  31 => 
  array (
    'dept_code' => 64,
    'dept_nom' => 'Pyrenees-Atlantiques',
    'total_visiteurs' => 180,
  ),
  32 => 
  array (
    'dept_code' => 63,
    'dept_nom' => 'Puy-de-Dome',
    'total_visiteurs' => 450,
  ),
  33 => 
  array (
    'dept_code' => 62,
    'dept_nom' => 'Pas-de-Calais',
    'total_visiteurs' => 300,
  ),
  34 => 
  array (
    'dept_code' => 61,
    'dept_nom' => 'Orne',
    'total_visiteurs' => 400,
  ),
  35 => 
  array (
    'dept_code' => 60,
    'dept_nom' => 'Oise',
    'total_visiteurs' => 2300,
  ),
  36 => 
  array (
    'dept_code' => 59,
    'dept_nom' => 'Nord',
    'total_visiteurs' => 5000,
  ),
  37 => 
  array (
    'dept_code' => 58,
    'dept_nom' => 'Nievre',
    'total_visiteurs' => 450,
  ),
  38 => 
  array (
    'dept_code' => 57,
    'dept_nom' => 'Moselle',
    'total_visiteurs' => 600,
  ),
  39 => 
  array (
    'dept_code' => 56,
    'dept_nom' => 'Morbihan',
    'total_visiteurs' => 2500,
  ),
  40 => 
  array (
    'dept_code' => 55,
    'dept_nom' => 'Meuse',
    'total_visiteurs' => 800,
  ),
  41 => 
  array (
    'dept_code' => 54,
    'dept_nom' => 'Meurthe-et-Moselle',
    'total_visiteurs' => 4000,
  ),
  42 => 
  array (
    'dept_code' => 53,
    'dept_nom' => 'Mayenne',
    'total_visiteurs' => 120,
  ),
  43 => 
  array (
    'dept_code' => 52,
    'dept_nom' => 'Haute-Marne',
    'total_visiteurs' => 500,
  ),
  44 => 
  array (
    'dept_code' => 51,
    'dept_nom' => 'Marne',
    'total_visiteurs' => 1500,
  ),
  45 => 
  array (
    'dept_code' => 50,
    'dept_nom' => 'Manche',
    'total_visiteurs' => 3000,
  ),
  46 => 
  array (
    'dept_code' => 49,
    'dept_nom' => 'Maine-et-Loire',
    'total_visiteurs' => 0,
  ),
  47 => 
  array (
    'dept_code' => 48,
    'dept_nom' => 'Lozere',
    'total_visiteurs' => 800,
  ),
  48 => 
  array (
    'dept_code' => 47,
    'dept_nom' => 'Lot-et-Garonne',
    'total_visiteurs' => 180,
  ),
  49 => 
  array (
    'dept_code' => 46,
    'dept_nom' => 'Lot',
    'total_visiteurs' => 350,
  ),
  50 => 
  array (
    'dept_code' => 45,
    'dept_nom' => 'Loiret',
    'total_visiteurs' => 300,
  ),
  51 => 
  array (
    'dept_code' => 44,
    'dept_nom' => 'Loire-Atlantique',
    'total_visiteurs' => 650,
  ),
  52 => 
  array (
    'dept_code' => 43,
    'dept_nom' => 'Haute-Loire',
    'total_visiteurs' => 400,
  ),
  53 => 
  array (
    'dept_code' => 42,
    'dept_nom' => 'Loire',
    'total_visiteurs' => 2500,
  ),
  54 => 
  array (
    'dept_code' => 41,
    'dept_nom' => 'Loir-et-Cher',
    'total_visiteurs' => 1000,
  ),
  55 => 
  array (
    'dept_code' => 40,
    'dept_nom' => 'Landes',
    'total_visiteurs' => 1800,
  ),
  56 => 
  array (
    'dept_code' => 39,
    'dept_nom' => 'Jura',
    'total_visiteurs' => 600,
  ),
  57 => 
  array (
    'dept_code' => 38,
    'dept_nom' => 'Isere',
    'total_visiteurs' => 400,
  ),
  58 => 
  array (
    'dept_code' => 37,
    'dept_nom' => 'Indre-et-Loire',
    'total_visiteurs' => 850,
  ),
  59 => 
  array (
    'dept_code' => 36,
    'dept_nom' => 'Indre',
    'total_visiteurs' => 0,
  ),
  60 => 
  array (
    'dept_code' => 35,
    'dept_nom' => 'Ille-et-Vilaine',
    'total_visiteurs' => 3000,
  ),
  61 => 
  array (
    'dept_code' => 34,
    'dept_nom' => 'Herault',
    'total_visiteurs' => 200,
  ),
  62 => 
  array (
    'dept_code' => 33,
    'dept_nom' => 'Gironde',
    'total_visiteurs' => 2100,
  ),
  63 => 
  array (
    'dept_code' => 32,
    'dept_nom' => 'Gers',
    'total_visiteurs' => 6000,
  ),
  64 => 
  array (
    'dept_code' => 31,
    'dept_nom' => 'Haute-Garonne',
    'total_visiteurs' => 800,
  ),
  65 => 
  array (
    'dept_code' => 30,
    'dept_nom' => 'Gard',
    'total_visiteurs' => 1400,
  ),
  66 => 
  array (
    'dept_code' => '2B',
    'dept_nom' => 'Haute-Corse',
    'total_visiteurs' => 350,
  ),
  67 => 
  array (
    'dept_code' => '2A',
    'dept_nom' => 'Corse-du-Sud',
    'total_visiteurs' => 200,
  ),
  68 => 
  array (
    'dept_code' => 29,
    'dept_nom' => 'Finistere',
    'total_visiteurs' => 1200,
  ),
  69 => 
  array (
    'dept_code' => 28,
    'dept_nom' => 'Eure-et-Loir',
    'total_visiteurs' => 1500,
  ),
  70 => 
  array (
    'dept_code' => 27,
    'dept_nom' => 'Eure',
    'total_visiteurs' => 350,
  ),
  71 => 
  array (
    'dept_code' => 26,
    'dept_nom' => 'Drome',
    'total_visiteurs' => 150,
  ),
  72 => 
  array (
    'dept_code' => 25,
    'dept_nom' => 'Doubs',
    'total_visiteurs' => 280,
  ),
  73 => 
  array (
    'dept_code' => 24,
    'dept_nom' => 'Dordogne',
    'total_visiteurs' => 400,
  ),
  74 => 
  array (
    'dept_code' => 23,
    'dept_nom' => 'Creuse',
    'total_visiteurs' => 80,
  ),
  75 => 
  array (
    'dept_code' => 22,
    'dept_nom' => 'Cotes-d\'Armor',
    'total_visiteurs' => 1500,
  ),
  76 => 
  array (
    'dept_code' => 21,
    'dept_nom' => 'Cote-d\'Or',
    'total_visiteurs' => 200,
  ),
  77 => 
  array (
    'dept_code' => 19,
    'dept_nom' => 'Correze',
    'total_visiteurs' => 450,
  ),
  78 => 
  array (
    'dept_code' => 18,
    'dept_nom' => 'Cher',
    'total_visiteurs' => 300,
  ),
  79 => 
  array (
    'dept_code' => 17,
    'dept_nom' => 'Charente-Maritime',
    'total_visiteurs' => 180,
  ),
  80 => 
  array (
    'dept_code' => 16,
    'dept_nom' => 'Charente',
    'total_visiteurs' => 350,
  ),
  81 => 
  array (
    'dept_code' => 15,
    'dept_nom' => 'Cantal',
    'total_visiteurs' => 600,
  ),
  82 => 
  array (
    'dept_code' => 14,
    'dept_nom' => 'Calvados',
    'total_visiteurs' => 4500,
  ),
  83 => 
  array (
    'dept_code' => 13,
    'dept_nom' => 'Bouches-du-Rhone',
    'total_visiteurs' => 3900,
  ),
  84 => 
  array (
    'dept_code' => 12,
    'dept_nom' => 'Aveyron',
    'total_visiteurs' => 650,
  ),
  85 => 
  array (
    'dept_code' => 11,
    'dept_nom' => 'Aude',
    'total_visiteurs' => 2800,
  ),
  86 => 
  array (
    'dept_code' => 10,
    'dept_nom' => 'Aube',
    'total_visiteurs' => 500,
  ),
  87 => 
  array (
    'dept_code' => '09',
    'dept_nom' => 'Ariege',
    'total_visiteurs' => 120,
  ),
  88 => 
  array (
    'dept_code' => '08',
    'dept_nom' => 'Ardennes',
    'total_visiteurs' => 200,
  ),
  89 => 
  array (
    'dept_code' => '07',
    'dept_nom' => 'Ardeche',
    'total_visiteurs' => 150,
  ),
  90 => 
  array (
    'dept_code' => '06',
    'dept_nom' => 'Alpes-Maritimes',
    'total_visiteurs' => 300,
  ),
  91 => 
  array (
    'dept_code' => '05',
    'dept_nom' => 'Hautes-Alpes',
    'total_visiteurs' => 950,
  ),
  92 => 
  array (
    'dept_code' => '04',
    'dept_nom' => 'Alpes-de-Haute-Provence',
    'total_visiteurs' => 180,
  ),
  93 => 
  array (
    'dept_code' => '03',
    'dept_nom' => 'Allier',
    'total_visiteurs' => 0,
  ),
  94 => 
  array (
    'dept_code' => '02',
    'dept_nom' => 'Aisne',
    'total_visiteurs' => 0,
  ),
  95 => 
  array (
    'dept_code' => '01',
    'dept_nom' => 'Ain',
    'total_visiteurs' => 0,
  ),
);
$data_visites = array (
  0 => 
  array (
    'dept_code' => '77',
    'nom_site' => '"Disneyland Paris"',
    'visiteurs' => 15000,
  ),
  1 => 
  array (
    'dept_code' => '75',
    'nom_site' => '"Cathédrale Notre-Dame de Paris"',
    'visiteurs' => 12000,
  ),
  2 => 
  array (
    'dept_code' => '78',
    'nom_site' => '"Château de Versailles"',
    'visiteurs' => 8100,
  ),
  3 => 
  array (
    'dept_code' => '32',
    'nom_site' => '"Sanctuaire de Lourdes"',
    'visiteurs' => 6000,
  ),
  4 => 
  array (
    'dept_code' => '59',
    'nom_site' => 'Vieux-Lille',
    'visiteurs' => 5000,
  ),
  5 => 
  array (
    'dept_code' => '14',
    'nom_site' => '"Plages du Débarquement"',
    'visiteurs' => 4500,
  ),
  6 => 
  array (
    'dept_code' => '67',
    'nom_site' => '"Cathédrale de Strasbourg"',
    'visiteurs' => 4500,
  ),
  7 => 
  array (
    'dept_code' => '54',
    'nom_site' => '"Place Stanislas"',
    'visiteurs' => 4000,
  ),
  8 => 
  array (
    'dept_code' => '83',
    'nom_site' => '"Port de Saint-Tropez"',
    'visiteurs' => 4000,
  ),
  9 => 
  array (
    'dept_code' => '13',
    'nom_site' => '"Calanques de Marseille"',
    'visiteurs' => 3500,
  ),
  10 => 
  array (
    'dept_code' => '35',
    'nom_site' => '"Saint-Malo intra-muros"',
    'visiteurs' => 3000,
  ),
  11 => 
  array (
    'dept_code' => '50',
    'nom_site' => 'Mont-Saint-Michel',
    'visiteurs' => 3000,
  ),
  12 => 
  array (
    'dept_code' => '74',
    'nom_site' => '"Lac d\'Annecy"',
    'visiteurs' => 3000,
  ),
  13 => 
  array (
    'dept_code' => '42',
    'nom_site' => '"Basilique Notre-Dame de Fourvière"',
    'visiteurs' => 2500,
  ),
  14 => 
  array (
    'dept_code' => '56',
    'nom_site' => '"Golfe du Morbihan"',
    'visiteurs' => 2500,
  ),
  15 => 
  array (
    'dept_code' => '69',
    'nom_site' => '"Basilique de Fourvière"',
    'visiteurs' => 2500,
  ),
  16 => 
  array (
    'dept_code' => '60',
    'nom_site' => '"Parc Astérix"',
    'visiteurs' => 2300,
  ),
  17 => 
  array (
    'dept_code' => '85',
    'nom_site' => '"Puy du Fou"',
    'visiteurs' => 2300,
  ),
  18 => 
  array (
    'dept_code' => '33',
    'nom_site' => '"Dune du Pilat"',
    'visiteurs' => 2100,
  ),
  19 => 
  array (
    'dept_code' => '11',
    'nom_site' => '"Cité de Carcassonne"',
    'visiteurs' => 2000,
  ),
  20 => 
  array (
    'dept_code' => '80',
    'nom_site' => '"Baie de Somme"',
    'visiteurs' => 2000,
  ),
  21 => 
  array (
    'dept_code' => '86',
    'nom_site' => 'Futuroscope',
    'visiteurs' => 1900,
  ),
  22 => 
  array (
    'dept_code' => '40',
    'nom_site' => '"Dune du Pilat - Plages"',
    'visiteurs' => 1800,
  ),
  23 => 
  array (
    'dept_code' => '22',
    'nom_site' => '"Côte de Granit Rose"',
    'visiteurs' => 1500,
  ),
  24 => 
  array (
    'dept_code' => '28',
    'nom_site' => '"Cathédrale de Chartres"',
    'visiteurs' => 1500,
  ),
  25 => 
  array (
    'dept_code' => '51',
    'nom_site' => '"Cathédrale de Reims"',
    'visiteurs' => 1500,
  ),
  26 => 
  array (
    'dept_code' => '92',
    'nom_site' => '"La Défense"',
    'visiteurs' => 1500,
  ),
  27 => 
  array (
    'dept_code' => '30',
    'nom_site' => '"Pont du Gard"',
    'visiteurs' => 1400,
  ),
  28 => 
  array (
    'dept_code' => '29',
    'nom_site' => '"Pointe du Raz"',
    'visiteurs' => 1200,
  ),
  29 => 
  array (
    'dept_code' => '73',
    'nom_site' => '"Lac du Bourget"',
    'visiteurs' => 1200,
  ),
  30 => 
  array (
    'dept_code' => '41',
    'nom_site' => '"Château de Chambord"',
    'visiteurs' => 1000,
  ),
  31 => 
  array (
    'dept_code' => '05',
    'nom_site' => '"Parc national des Écrins"',
    'visiteurs' => 950,
  ),
  32 => 
  array (
    'dept_code' => '79',
    'nom_site' => '"Marais Poitevin"',
    'visiteurs' => 900,
  ),
  33 => 
  array (
    'dept_code' => '37',
    'nom_site' => '"Château de Chenonceau"',
    'visiteurs' => 850,
  ),
  34 => 
  array (
    'dept_code' => '65',
    'nom_site' => '"Parc national des Pyrénées"',
    'visiteurs' => 850,
  ),
  35 => 
  array (
    'dept_code' => '11',
    'nom_site' => '"Parc naturel régional de la Narbonnaise"',
    'visiteurs' => 800,
  ),
  36 => 
  array (
    'dept_code' => '31',
    'nom_site' => '"Basilique Saint-Sernin"',
    'visiteurs' => 800,
  ),
  37 => 
  array (
    'dept_code' => '48',
    'nom_site' => '"Gorges du Tarn"',
    'visiteurs' => 800,
  ),
  38 => 
  array (
    'dept_code' => '55',
    'nom_site' => '"Verdun - Champs de bataille"',
    'visiteurs' => 800,
  ),
  39 => 
  array (
    'dept_code' => '44',
    'nom_site' => '"Machines de l\'île"',
    'visiteurs' => 650,
  ),
  40 => 
  array (
    'dept_code' => '84',
    'nom_site' => '"Palais des Papes"',
    'visiteurs' => 650,
  ),
  41 => 
  array (
    'dept_code' => '15',
    'nom_site' => '"Puy Mary"',
    'visiteurs' => 600,
  ),
  42 => 
  array (
    'dept_code' => '39',
    'nom_site' => '"Parc naturel du Haut-Jura"',
    'visiteurs' => 600,
  ),
  43 => 
  array (
    'dept_code' => '57',
    'nom_site' => '"Cathédrale de Metz"',
    'visiteurs' => 600,
  ),
  44 => 
  array (
    'dept_code' => '10',
    'nom_site' => '"Lac du Der-Chantecoat"',
    'visiteurs' => 500,
  ),
  45 => 
  array (
    'dept_code' => '52',
    'nom_site' => '"Lac du Der"',
    'visiteurs' => 500,
  ),
  46 => 
  array (
    'dept_code' => '72',
    'nom_site' => '"Circuit des 24 Heures du Mans"',
    'visiteurs' => 500,
  ),
  47 => 
  array (
    'dept_code' => '81',
    'nom_site' => '"Albi - Cité épiscopale"',
    'visiteurs' => 500,
  ),
  48 => 
  array (
    'dept_code' => '91',
    'nom_site' => '"Château de Fontainebleau"',
    'visiteurs' => 500,
  ),
  49 => 
  array (
    'dept_code' => '19',
    'nom_site' => '"Gouffre de Padirac"',
    'visiteurs' => 450,
  ),
  50 => 
  array (
    'dept_code' => '58',
    'nom_site' => '"Parc du Morvan"',
    'visiteurs' => 450,
  ),
  51 => 
  array (
    'dept_code' => '63',
    'nom_site' => 'Vulcania',
    'visiteurs' => 450,
  ),
  52 => 
  array (
    'dept_code' => '12',
    'nom_site' => '"Viaduc de Millau"',
    'visiteurs' => 400,
  ),
  53 => 
  array (
    'dept_code' => '13',
    'nom_site' => '"Pont d\'Avignon"',
    'visiteurs' => 400,
  ),
  54 => 
  array (
    'dept_code' => '24',
    'nom_site' => '"Grotte de Lascaux IV"',
    'visiteurs' => 400,
  ),
  55 => 
  array (
    'dept_code' => '38',
    'nom_site' => '"Grande Mosquée de Lyon"',
    'visiteurs' => 400,
  ),
  56 => 
  array (
    'dept_code' => '43',
    'nom_site' => '"Le Puy-en-Velay"',
    'visiteurs' => 400,
  ),
  57 => 
  array (
    'dept_code' => '61',
    'nom_site' => '"Basilique Sainte-Thérèse"',
    'visiteurs' => 400,
  ),
  58 => 
  array (
    'dept_code' => '16',
    'nom_site' => '"Cognac - Maisons de cognac"',
    'visiteurs' => 350,
  ),
  59 => 
  array (
    'dept_code' => '27',
    'nom_site' => '"Abbaye du Mont-Saint-Michel"',
    'visiteurs' => 350,
  ),
  60 => 
  array (
    'dept_code' => '2B',
    'nom_site' => '"Îles Lavezzi"',
    'visiteurs' => 350,
  ),
  61 => 
  array (
    'dept_code' => '46',
    'nom_site' => '"Parc naturel des Causses du Quercy"',
    'visiteurs' => 350,
  ),
  62 => 
  array (
    'dept_code' => '88',
    'nom_site' => '"Place Stanislas"',
    'visiteurs' => 350,
  ),
  63 => 
  array (
    'dept_code' => '06',
    'nom_site' => '"Musée Matisse"',
    'visiteurs' => 300,
  ),
  64 => 
  array (
    'dept_code' => '18',
    'nom_site' => '"Cathédrale de Bourges"',
    'visiteurs' => 300,
  ),
  65 => 
  array (
    'dept_code' => '45',
    'nom_site' => '"Cathédrale Sainte-Croix d\'Orléans"',
    'visiteurs' => 300,
  ),
  66 => 
  array (
    'dept_code' => '62',
    'nom_site' => 'Notre-Dame-de-Lorette',
    'visiteurs' => 300,
  ),
  67 => 
  array (
    'dept_code' => '87',
    'nom_site' => 'Oradour-sur-Glane',
    'visiteurs' => 300,
  ),
  68 => 
  array (
    'dept_code' => '25',
    'nom_site' => '"Citadelle de Besançon"',
    'visiteurs' => 280,
  ),
  69 => 
  array (
    'dept_code' => '12',
    'nom_site' => '"Cathédrale Saint-Jean"',
    'visiteurs' => 250,
  ),
  70 => 
  array (
    'dept_code' => '68',
    'nom_site' => '"Écomusée d\'Alsace"',
    'visiteurs' => 250,
  ),
  71 => 
  array (
    'dept_code' => '08',
    'nom_site' => '"Place Ducale de Charleville-Mézières"',
    'visiteurs' => 200,
  ),
  72 => 
  array (
    'dept_code' => '21',
    'nom_site' => '"Château de Fougères"',
    'visiteurs' => 200,
  ),
  73 => 
  array (
    'dept_code' => '2A',
    'nom_site' => '"Réserve naturelle de Scandola"',
    'visiteurs' => 200,
  ),
  74 => 
  array (
    'dept_code' => '34',
    'nom_site' => '"Grotte de Clamouse"',
    'visiteurs' => 200,
  ),
  75 => 
  array (
    'dept_code' => '66',
    'nom_site' => '"Palais des rois de Majorque"',
    'visiteurs' => 200,
  ),
  76 => 
  array (
    'dept_code' => '71',
    'nom_site' => '"Abbaye de Cluny"',
    'visiteurs' => 200,
  ),
  77 => 
  array (
    'dept_code' => '90',
    'nom_site' => '"Lion de Belfort"',
    'visiteurs' => 200,
  ),
  78 => 
  array (
    'dept_code' => '94',
    'nom_site' => '"Château de Vincennes"',
    'visiteurs' => 200,
  ),
  79 => 
  array (
    'dept_code' => '04',
    'nom_site' => '"Citadelle de Sisteron"',
    'visiteurs' => 180,
  ),
  80 => 
  array (
    'dept_code' => '17',
    'nom_site' => '"Fort Boyard"',
    'visiteurs' => 180,
  ),
  81 => 
  array (
    'dept_code' => '47',
    'nom_site' => '"Agen et sa région"',
    'visiteurs' => 180,
  ),
  82 => 
  array (
    'dept_code' => '64',
    'nom_site' => '"Grottes de Bétharram"',
    'visiteurs' => 180,
  ),
  83 => 
  array (
    'dept_code' => '82',
    'nom_site' => '"Abbaye de Moissac"',
    'visiteurs' => 180,
  ),
  84 => 
  array (
    'dept_code' => '07',
    'nom_site' => '"Palais idéal du facteur Cheval"',
    'visiteurs' => 150,
  ),
  85 => 
  array (
    'dept_code' => '26',
    'nom_site' => '"Palais idéal du facteur Cheval"',
    'visiteurs' => 150,
  ),
  86 => 
  array (
    'dept_code' => '93',
    'nom_site' => '"Basilique Saint-Denis"',
    'visiteurs' => 150,
  ),
  87 => 
  array (
    'dept_code' => '09',
    'nom_site' => '"Château de Foix"',
    'visiteurs' => 120,
  ),
  88 => 
  array (
    'dept_code' => '53',
    'nom_site' => '"Basilique d\'Évron"',
    'visiteurs' => 120,
  ),
  89 => 
  array (
    'dept_code' => '70',
    'nom_site' => '"Chapelle de Ronchamp"',
    'visiteurs' => 100,
  ),
  90 => 
  array (
    'dept_code' => '23',
    'nom_site' => '"Tapisseries d\'Aubusson"',
    'visiteurs' => 80,
  ),
  91 => 
  array (
    'dept_code' => '89',
    'nom_site' => '"Abbaye de Pontigny"',
    'visiteurs' => 80,
  ),
);
$data_regions = array (
  0 => 
  array (
    'region_nom' => 'Île-de-France',
    'total_visiteurs' => 37450,
  ),
  1 => 
  array (
    'region_nom' => 'Occitanie',
    'total_visiteurs' => 14850,
  ),
  2 => 
  array (
    'region_nom' => 'Grand Est',
    'total_visiteurs' => 13200,
  ),
  3 => 
  array (
    'region_nom' => 'Auvergne-Rhône-Alpes',
    'total_visiteurs' => 11350,
  ),
  4 => 
  array (
    'region_nom' => 'Provence-Alpes-Côte d’Azur',
    'total_visiteurs' => 9980,
  ),
  5 => 
  array (
    'region_nom' => 'Hauts-de-France',
    'total_visiteurs' => 9600,
  ),
  6 => 
  array (
    'region_nom' => 'Nouvelle-Aquitaine',
    'total_visiteurs' => 8820,
  ),
  7 => 
  array (
    'region_nom' => 'Normandie',
    'total_visiteurs' => 8250,
  ),
  8 => 
  array (
    'region_nom' => 'Bretagne',
    'total_visiteurs' => 8200,
  ),
  9 => 
  array (
    'region_nom' => 'Centre-Val de Loire',
    'total_visiteurs' => 3950,
  ),
  10 => 
  array (
    'region_nom' => 'Pays de la Loire',
    'total_visiteurs' => 3570,
  ),
  11 => 
  array (
    'region_nom' => 'Bourgogne-Franche-Comté',
    'total_visiteurs' => 2110,
  ),
  12 => 
  array (
    'region_nom' => 'Corse',
    'total_visiteurs' => 550,
  ),
);
