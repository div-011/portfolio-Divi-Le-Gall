# PARTICIPATION MEMBRES EQUIPE A6

## TABLEAU DE SYNTHESE JEU DE FICHIERS

Temps total : ??

| Membre | %   | Commentaire |
| ------ | --- | --------------------------------------------------------------------------------------------------|
| Emré   | 25  | Génération des rendus HTML et PDF + traitement des données en PHP                                 |
| Divi   | 25  |  |
| Hugo   | 25  |  |
| Marcel | 25  | Traitement des données en PHP                                                                     |    

## TACHES

Étape B-1 : Chaîne de traitement  
- Analyse des fichiers fournis (Excel, fichiers texte DEPTS et REGIONS)  
- Définition de l’ordre des traitements à effectuer  
- Mise en place d’un script principal pour automatiser l’ensemble du processus  
- Utilisation de Docker pour garantir un environnement identique à chaque exécution  

Étape B-2 : Conversion et nettoyage des données  
- Conversion du fichier Excel en CSV  
- Nettoyage du CSV (suppression des lignes inutiles, réorganisation des colonnes)  
- Vérification de la cohérence des données obtenues  
- Génération d’un fichier CSV final exploitable par les scripts PHP 

Étape B-3 : Traitement des données en PHP  
- Lecture du fichier CSV nettoyé  
- Création des tableaux PHP correspondant aux tris demandés :
  - Tri par département  
  - Tri par nombre de visiteurs  
  - Synthèse par région  
- Génération automatique du fichier `data.php` contenant les tableaux utilisés dans `generateur_html.php` 

Étape B-4 : Génération des rendus HTML et PDF  
- Création des pages HTML à partir des tableaux PHP  
- Mise en forme avec une feuille de style CSS fournie  
- Conversion automatique des pages HTML en fichiers PDF  
- Vérification de la conformité des résultats avec les consignes  

Étape B-5 : Organisation finale et tests  
- Organisation des dossiers d’entrée et de sortie  
- Tests complets de la chaîne de traitement avec un seul script  
- Vérification que l’exécution fonctionne sans intervention manuelle  
